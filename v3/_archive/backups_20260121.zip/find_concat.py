filename = r"d:\projects\tributary pro v3.0 12-18-25\tributary-pro-v3\v3\index_BROKEN_20260121.html"

try:
    with open(filename, 'r', encoding='utf-8') as f:
        lines = f.readlines()
        
    print(f"Total lines: {len(lines)}")
    for i, line in enumerate(lines):
        if "</html>" in line:
            print(f"Found /html at line {i+1}")
        if "updateBeamParam" in line and "function" in line:
             print(f"Found updateBeamParam def at line {i+1}")
except Exception as e:
    print(f"Error: {e}")
